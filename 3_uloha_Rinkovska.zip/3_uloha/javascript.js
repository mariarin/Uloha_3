
// Premenna
var cislo1 = 50;
var cislo2 = 10;
var vysledok = (cislo1 + cislo2)/2;
document.getElementById("vypocet_priemeru").innerHTML ="Priemer hodnot je: " + vysledok;


//Operator
var dx = 10;
var dy = 15;
var dp = dp = Math.sqrt(dx*dx + dy*dy);
document.getElementById("polohova_odchylka").innerHTML = "Vysledna polohova odchylka " + dp;

//funkcia
var x = percentualne(56, 100);
document.getElementById("percento").innerHTML ="Minimalny pocet bodov v percentach: "  +x;
function percentualne(a, b) {
  return a / b;
}

// Tvorba objektu
var adresa= {Mesto:"Litmanova", ulica:"Litmanova", cd:"72", PSC: "065 31"};
// Vypisanie na display
document.getElementById("trvale_bydlisko").innerHTML =
" Mesto: "  + adresa.Mesto +  
" <br> Ulica: " + adresa.ulica + 
" <br> cd: " + adresa.cd+ 
" <br> PSC: " + adresa.PSC;

// Array

var tyzden = ["Pondelok", "Utorok", "Streda", "Stvrtok","Piatok", "Sobota", "Nedela"];
var posledny_den = tyzden[tyzden.length-1];
document.getElementById("koniecTyzdna").innerHTML = "Posledny den v tyzdni je: " +posledny_den;


//if else
var vek = 15;
 if( vek > 18 ) {
     greeting = "si plnolety.";
                document.getElementById("dospelost").innerHTML ="Tvoj vek je: " + vek+ " a " +greeting;
                  } else {
                      greeting = "nie si plnolety.";
                      document.getElementById("dospelost").innerHTML = "Tvoj vek je: " + vek+ " a " +greeting;
               }

// cykly
var ingrediencie = ["vajicka", "praskovy cukor", "mlieko", "olej", "muka", "prasok do peciva", "vanilkovy cukor"];
var i = 0;
var vsetkyingr = ingrediencie.length;
var recept= "";
for ( i=0; i < vsetkyingr; i++) {
  recept += ingrediencie[i] + "<br>";
}
document.getElementById("pecenie").innerHTML = "Na upecenie kolaca budeme potrebovat: <br>" +recept;

// array.map
var cisla1 = [0, 1, 2, 3, 4];
var cisla2 = cisla1.map(myFunction1);
document.getElementById("nasobenie_pola").innerHTML ="Pole je vynasobene cislom 2 a vysledok je: " +cisla2;
function myFunction1(value) {
  return value * 2;
}

//array.forEach
var text= "";
var numbers = [10, 20, 30, 40, 50];
numbers.forEach(funkcianaeach);
document.getElementById("each").innerHTML = "Cisla v poli: 10, 20, 30, 40, 50 maju indexy: <br> " + text;
function funkcianaeach(value, index, array) {
  text = text + index + "<br>"; 
}

//arary find
var cislapola = [1, 10, 50, 7, 9];
var prve = cislapola.find(hladanie);

document.getElementById("najdenieindexuvpoli").innerHTML = "Na tretom mieste je cislo " + prve+ ".";

function hladanie(value, index, array) {
  return index >1;
}


// array findIndex
var cislaindex = [10, 20, 15, 25, 40];
var prvenajvacsie = cislaindex.findIndex(indexfind);

document.getElementById("indexindex").innerHTML = "Index cisla vacsieho ako je 25 ma index: " + prvenajvacsie;

function indexfind(value, index, array) {
  return value > 25;
}

//array push
var znamky = ["A", "B", "C", "D", "E"];
document.getElementById("vstupny").innerHTML = " uspesne znamky:" +znamky;
znamky.push("FX");
document.getElementById("vysledny").innerHTML = "vsetky znamky:" +znamky;

//array join
var ovocie = ["Jablko", "Hruska", "Ananas", "Slivka"];
var x = document.getElementById("typy_ovocia");
x.innerHTML = ovocie.join(" alebo ");